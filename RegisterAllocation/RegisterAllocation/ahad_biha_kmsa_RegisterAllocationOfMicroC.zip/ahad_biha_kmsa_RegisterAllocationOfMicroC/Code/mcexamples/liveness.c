int p;
void main(int n) {
    int t;
    int i;
    i = 1;
    int c;
    c = 2;
    while(i > n ) {
        int s;
        s = 3;
    }
    print p;
    int x;
    x = 4;
    int y;
    y = 5;
    print add(x,y);
    
}

int add(int a, int b) {
    p = 6;
    return a + b;
}