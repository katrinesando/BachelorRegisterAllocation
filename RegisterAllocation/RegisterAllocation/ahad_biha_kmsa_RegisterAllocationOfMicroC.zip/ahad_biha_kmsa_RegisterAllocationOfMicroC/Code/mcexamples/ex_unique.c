﻿int p;
void main(int n) {
    p = 1;
    if (n < 1) {
        int h;
        h = 5;
    }
    print n;
}