﻿/* simple test for printing either "2" or a depending on if input number is greater than 2 */
void main(int a)
{
    if (a > 2)
    {
        print (a);
    }
    else
    {
        print (2);
    }
}