﻿void main(int n)
{
    int a[15];
    int b[15];
    a[1+n] = b[0+n] = n;
	print (a[1+n]);
	print (b[n]);
}
