﻿void main(int n)
{
    int i; 
    int u;
    int used[100];
    int diag1[100];
    int diag2[100];
    int col[100];
    i = u = 1;
    while (u <= n && (diag1[u-i+n] ))
    {
        u = u + 1;
        print u;
    }
}
