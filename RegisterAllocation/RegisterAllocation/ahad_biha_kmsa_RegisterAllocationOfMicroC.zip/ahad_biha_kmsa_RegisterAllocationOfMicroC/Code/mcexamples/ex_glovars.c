int num;
//more glovars for testing
int i;
//int h;
void main()
{
   num = 3;
   i = 5;
   print i;
   print num;
}
//should print 5 3