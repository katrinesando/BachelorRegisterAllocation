﻿void main(int n)
{
    int a;
    a = 4;
    int b;
    b = 5;
    print (silly(n, a, b));
	
}

int silly(int a, int b, int c)
{	
    return a+b+c;
}
