﻿
int p;
void main(int n)
{
    p = n;
    int trash;
    int i;
    while (n > i)
    {
        int c;
        c = 190;
        i = i + 1;
    }
    int s;
    s = 2;
    print s;
}