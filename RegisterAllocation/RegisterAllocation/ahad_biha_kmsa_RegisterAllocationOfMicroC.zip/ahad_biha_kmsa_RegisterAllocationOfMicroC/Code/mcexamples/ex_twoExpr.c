﻿void main()
{
    int a;
    int b;
    int t1;
    t1 = a+b;
    b = a+a+t1;
}
