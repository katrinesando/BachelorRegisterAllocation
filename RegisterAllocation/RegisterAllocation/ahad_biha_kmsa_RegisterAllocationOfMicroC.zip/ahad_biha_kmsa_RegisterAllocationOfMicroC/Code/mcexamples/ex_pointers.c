﻿
void main() {
   int i;
   int *p;
   int b;
   b = 200;
   p = &i;
   *p = 277;
   print(i);
   print b;
}