﻿/* tests various operations from prim2 */
void main(int a)
{
    print (a+a);
    print (a-a);
    print (a*a);
    print (a/2);
    print (a%2);
    print (a==0);
    print (a!=0);
    print (!a);
    print (a||4);
    print (a&&4);
    print (a<=4);
    print (a>=4);
}