﻿void main()
{
    int z;
    z = addManyVar();
    print z;
}

int add()
{
    int n;
    n = 5;

    int t;
    t = 84 ;

    int g;
    int r;
    int u;
    int p;
    int a;
    int b;
    int o;

    g = t+n;

    return n;
}

int addManyVar()
{
    int a;int b;int c;int d;
    int e;int f;int g;int h;
    int i;int j;int k;int l;
    int m;int n;int o;int p;
    int q;int r;int s;int t;
    int u;int v;
    v = 1000;
    
    while(v>0)
    {
        a = 1;
        b = a;
        c = b+a-1+1-1;
        d = e = 1;
        f = b;       
        g = a;        
        h = g; 
        i = f + g -d;
        j =k =l = m = n = o = p = q = 1;      
        r = s = t = u = 1;        
        
        u = 1 - u + t - s + r - q + p - p + p - p + p - o + n - m + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - l + l -l + l - l + l - k + j - i + h - g + f - e + d - c + b - a + j;

        if(v>50 && v<75)
        {
            int x;
            x = 10000;
            while(x>0)
            {
                int y;
                y = add();
                y = add();
                y = add();
                y = y;
                if(1==1)
                {
                    x = (x+x+x+x+x+x+x+x+x+x+x + y - y+ y - y - (x*10));
                }
                x = x-1+1-1+1-1+1-1+1-1+1-1+1-1+1-1;

                y = u;
            }
        }
        v = v -1;
    }
    return 0;    
}
